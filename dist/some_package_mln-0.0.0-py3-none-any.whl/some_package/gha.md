Some changes


Some new changes